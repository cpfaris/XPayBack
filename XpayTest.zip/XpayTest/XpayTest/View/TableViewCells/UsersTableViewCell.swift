//
//  UsersTableViewCell.swift
//  XpayTest
//
//  Created by FARIS CP on 01/09/23.
//

import UIKit

class UsersTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    //MARK: - @ Outlets
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var viewBackGround: UIView!
    @IBOutlet weak var lblName: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        self.imgProfile.layer.cornerRadius = self.imgProfile.frame.height/2.0
        self.imgProfile.clipsToBounds = true
        self.viewBackGround.layer.cornerRadius = 10
        imgProfile.layer.borderWidth = 1.5
        imgProfile.layer.borderColor = UIColor.gray.cgColor
    }
    
}

