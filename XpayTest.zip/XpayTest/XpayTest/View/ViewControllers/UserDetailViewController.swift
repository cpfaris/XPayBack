//
//  UserDetailViewController.swift
//  XpayTest
//
//  Created by FARIS CP on 01/09/23.
//

import UIKit
import Foundation
class UserDetailViewController: UIViewController {
    //MARK: - @ Outlets
    @IBOutlet weak var imgPicture: UIImageView!
    @IBOutlet weak var detailsView: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblID: UILabel!
    @IBOutlet weak var lblPhone: UILabel!
    @IBOutlet weak var lblGender: UILabel!
    @IBOutlet weak var lblAge: UILabel!
    @IBOutlet weak var lblBloodGroup: UILabel!
    @IBOutlet weak var lblCompanyName: UILabel!
    @IBOutlet weak var lblDepartment: UILabel!
    var selectedUser : Users?
    
    override func viewDidLoad() {
        super.viewDidLoad()
      setUpUI()
    }
    func setUpUI(){
        self.navigationItem.title = "Details"
        imgPicture.downloaded(from: (selectedUser?.image ?? ""))
        self.imgPicture.layer.cornerRadius = self.imgPicture.frame.height/2.0
        self.imgPicture.clipsToBounds = true
        self.detailsView.layer.cornerRadius = 10
        imgPicture.layer.borderWidth = 1.5
        imgPicture.layer.borderColor = UIColor.gray.cgColor
        lblName.text = (selectedUser?.firstName ?? "") + " " + (selectedUser?.lastName ?? "")
        lblID.text = selectedUser?.id?.description
        lblPhone.text = selectedUser?.phone
        lblGender.text = selectedUser?.gender
        lblAge.text = selectedUser?.age?.description
        lblBloodGroup.text = selectedUser?.bloodGroup
        lblCompanyName.text = selectedUser?.company?.name
        lblDepartment.text = selectedUser?.company?.department
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension UIImageView {
    func downloaded(from url: URL, contentMode mode: ContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
            else { return }
            DispatchQueue.main.async() { [weak self] in
                self?.image = image
            }
        }.resume()
    }
    func downloaded(from link: String, contentMode mode: ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
}
