//
//  UsersViewController.swift
//  XpayTest
//
//  Created by FARIS CP on 01/09/23.
//

import UIKit

class UsersViewController: UIViewController{
    
    @IBOutlet weak var usersTableView: UITableView!
    var viewModel = UsersListViewModel()
    var skip = 0
    var activityView: UIActivityIndicatorView?
   
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        usersTableView.delegate = self
        usersTableView.dataSource = self
        registerNib()
        initViewModel()
        // Do any additional setup after loading the view.
    }
    
    func registerNib(){
        usersTableView.register(UINib.init(nibName: "UsersTableViewCell", bundle: Bundle.main), forCellReuseIdentifier: "UsersTableViewCell")
    }
    func initViewModel(){
        self.showActivityIndicator()
        viewModel.getUsersList(skip: 0)
    }
    //MARK: - @ Pagination
    func loadMoreCells(){
        let spinner = UIActivityIndicatorView(style: .gray)
        spinner.startAnimating()
        spinner.frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: usersTableView.bounds.width, height: CGFloat(44))
        if  self.viewModel.usersLists?.total == self.viewModel.users.count {
            usersTableView.tableFooterView = UIView()
            return
        }
        else{
            usersTableView.tableFooterView = spinner
            usersTableView.tableFooterView?.isHidden = false
        }
        if (self.viewModel.usersLists?.users?.count ?? 0 < self.viewModel.usersLists?.total ?? 0 ){
            skip = skip + 10
            print(skip)
            viewModel.getUsersList(skip: skip)
        }
    }
    func showActivityIndicator() {
        activityView = UIActivityIndicatorView(style: .large)
        activityView?.center = self.view.center
        self.view.addSubview(activityView!)
        activityView?.startAnimating()
    }
    func hideActivityIndicator(){
        if (activityView != nil){
            activityView?.stopAnimating()
        }
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
//MARK: - @ Table View
extension UsersViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.users.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UsersTableViewCell", for: indexPath) as! UsersTableViewCell
        cell.lblName.text = (viewModel.users[indexPath.row].firstName ?? "")  + " " + (viewModel.users[indexPath.row].lastName ?? "")
        cell.imgProfile.downloaded(from: (viewModel.users[indexPath.row].image ?? ""))
        let rows = tableView.numberOfRows(inSection: indexPath.section)
        if rows-2 == indexPath.row  {
            loadMoreCells()
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let destinationVc = storyBoard.instantiateViewController(withIdentifier: "UserDetailViewController") as! UserDetailViewController
        destinationVc.selectedUser = viewModel.users[indexPath.row]
        self.navigationController?.pushViewController(destinationVc, animated: true)
    }
}
//MARK: - @ protocols
extension UsersViewController : UsersListViewModelDelegate {
    func didFinishGettingData() {
        DispatchQueue.main.async {
            self.hideActivityIndicator()
            self.usersTableView.reloadData()
        }
    }
}
