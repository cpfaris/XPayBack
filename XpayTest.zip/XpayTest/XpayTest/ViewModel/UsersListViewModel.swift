//
//  UsersListViewModel.swift
//  XpayTest
//
//  Created by FARIS CP on 01/09/23.
//

import Foundation
import UIKit
protocol UsersListViewModelDelegate {
    
    func didFinishGettingData()
    
}

class UsersListViewModel{
    private var usersListService: UsersServiceProtocol
    var delegate: UsersListViewModelDelegate?
    var reloadTableView: (() -> Void)?
    
    var usersLists : UsersList?
    var skip : Int = 0
    var users : [Users] = []
   
    init(usersListService : UsersServiceProtocol = UsersService()) {
        self.usersListService = usersListService
    }
    //MARK: - @ API Call
    func getUsersList(skip: Int) {
        usersListService.getUsers(skip: skip) { [self] success, model, error in
            if success, let usersList = model {
                usersLists = usersList
                //users = usersList.users ?? []
                self.users.append(contentsOf: usersLists?.users ?? [])
               // self.users = self.users.sorted(by: { $0.firstName! < $1.firstName! })
                self.delegate?.didFinishGettingData()
            } else {
                print(error!)
            }
        }
    }
}

