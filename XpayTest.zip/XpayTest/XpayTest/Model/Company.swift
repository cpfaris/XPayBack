//
//  Company.swift
//  XpayTest
//
//  Created by FARIS CP on 01/09/23.
//
import Foundation
struct Company : Codable {
	let address : Address?
	let department : String?
	let name : String?
	let title : String?

	enum CodingKeys: String, CodingKey {

		case address = "address"
		case department = "department"
		case name = "name"
		case title = "title"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		address = try values.decodeIfPresent(Address.self, forKey: .address)
		department = try values.decodeIfPresent(String.self, forKey: .department)
		name = try values.decodeIfPresent(String.self, forKey: .name)
		title = try values.decodeIfPresent(String.self, forKey: .title)
	}

}
