//
//  Bank.swift
//  XpayTest
//
//  Created by FARIS CP on 01/09/23.
//

import Foundation
struct Bank : Codable {
	let cardExpire : String?
	let cardNumber : String?
	let cardType : String?
	let currency : String?
	let iban : String?

	enum CodingKeys: String, CodingKey {

		case cardExpire = "cardExpire"
		case cardNumber = "cardNumber"
		case cardType = "cardType"
		case currency = "currency"
		case iban = "iban"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		cardExpire = try values.decodeIfPresent(String.self, forKey: .cardExpire)
		cardNumber = try values.decodeIfPresent(String.self, forKey: .cardNumber)
		cardType = try values.decodeIfPresent(String.self, forKey: .cardType)
		currency = try values.decodeIfPresent(String.self, forKey: .currency)
		iban = try values.decodeIfPresent(String.self, forKey: .iban)
	}

}
