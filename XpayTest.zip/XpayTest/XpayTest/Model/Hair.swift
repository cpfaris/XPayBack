//
//  Hair.swift
//  XpayTest
//
//  Created by FARIS CP on 01/09/23.
//

import Foundation
struct Hair : Codable {
	let color : String?
	let type : String?

	enum CodingKeys: String, CodingKey {

		case color = "color"
		case type = "type"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		color = try values.decodeIfPresent(String.self, forKey: .color)
		type = try values.decodeIfPresent(String.self, forKey: .type)
	}

}
