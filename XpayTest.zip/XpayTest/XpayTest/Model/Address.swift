//
//  Address.swift
//  XpayTest
//
//  Created by FARIS CP on 01/09/23.
//

import Foundation
struct Address : Codable {
	let address : String?
	let city : String?
	let coordinates : Coordinates?
	let postalCode : String?
	let state : String?

	enum CodingKeys: String, CodingKey {

		case address = "address"
		case city = "city"
		case coordinates = "coordinates"
		case postalCode = "postalCode"
		case state = "state"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		address = try values.decodeIfPresent(String.self, forKey: .address)
		city = try values.decodeIfPresent(String.self, forKey: .city)
		coordinates = try values.decodeIfPresent(Coordinates.self, forKey: .coordinates)
		postalCode = try values.decodeIfPresent(String.self, forKey: .postalCode)
		state = try values.decodeIfPresent(String.self, forKey: .state)
	}

}
