//
//  UesersService.swift
//  XpayTest
//
//  Created by FARIS CP on 01/09/23.
//

import Foundation
protocol UsersServiceProtocol {
    func getUsers(skip : Int, completion: @escaping (_ success: Bool, _ results: UsersList?, _ error: String?) -> ())
}

class UsersService: UsersServiceProtocol {
    
    func getUsers(skip :Int, completion: @escaping (Bool, UsersList?, String?) -> ()) {
        HttpRequestHelper().GET(url: "https://dummyjson.com/users?limit=10&skip=\(skip)", httpHeader: .application_json) { success, data in
            if success {
                do {
                    let jsonDecoder = JSONDecoder()
                    let responseModel = try jsonDecoder.decode(UsersList.self, from: data!)
                    completion(true, responseModel, nil)
                } catch {
                    completion(false, nil, "Error: Trying to parse Users to model")
                }
            } else {
                completion(false, nil, "Error: Users GET Request failed")
            }
        }
    }

}
