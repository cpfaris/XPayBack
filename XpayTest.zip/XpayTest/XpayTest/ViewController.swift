//
//  ViewController.swift
//  XpayTest
//
//  Created by FARIS CP on 01/09/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

